﻿using Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class FacturaData : IData<TbFactura>
    {
        private readonly IData<TbProducto> _productoData;
        private readonly IData<TbDetalleFactura> _DetalleFacturaData;
        private readonly DbProyectoInaContext _context;

        public FacturaData(DbProyectoInaContext context)
        {
            _context = context;
        }

        public FacturaData(IData<TbProducto> productoData, IData<TbDetalleFactura> detalleFacturaData, DbProyectoInaContext context)
        {
            _productoData = productoData;
            _DetalleFacturaData = detalleFacturaData;
            _context = context;
        }

        public async Task<bool> actualizar(TbFactura entity)
        {
            try
            {
                bool existe;
                var factura = await obtenerPorId(entity);
                foreach (var item in factura.TbDetalleFacturas)
                {
                    existe = false;
                    foreach (var item2 in entity.TbDetalleFacturas)
                    {
                        if (item2.IdDetalleFactura==item.IdDetalleFactura)
                        {
                            existe = true;
                            break;
                        }
                    }
                    if (!existe)
                    {
                        _context.Entry(item).State = EntityState.Deleted;
                    }

                }
                foreach (var detalle in entity.TbDetalleFacturas)
                {
                    TbProducto producto = new TbProducto();
                    producto.IdProducto = detalle.IdProducto;
                    producto = await _productoData.obtenerPorId(producto);

                    if (detalle.IdDetalleFactura!=0)
                    {

                        TbDetalleFactura dtf = new TbDetalleFactura();
                        dtf.IdDetalleFactura = detalle.IdDetalleFactura;
                        dtf = await _DetalleFacturaData.obtenerPorId(dtf);

                        _context.Entry(detalle).State = EntityState.Modified;
                        if (dtf.Cant > detalle.Cant)
                        {
                            if (detalle.Cant == 0)
                            {
                                producto.Stock += dtf.Cant;
                                await _productoData.actualizar(producto);
                            }
                            else
                            {
                                var cantReturn = dtf.Cant - detalle.Cant;
                                producto.Stock = producto.Stock + cantReturn;
                                await _productoData.actualizar(producto);
                            }
                        }
                        else if (dtf.Cant < detalle.Cant)
                        {
                            var cantReturn = detalle.Cant - dtf.Cant;
                            producto.Stock = producto.Stock - cantReturn;
                            await _productoData.actualizar(producto);
                        }
                    }
                    else
                    {
                        _context.Entry(detalle).State = EntityState.Added;
                        producto.Stock = producto.Stock - detalle.Cant;
                        await _productoData.actualizar(producto);
                    }

                }
                _context.Entry(entity).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<bool> eliminar(TbFactura entity)
        {
            try
            {
                _context.Entry(entity).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<TbFactura> guardar(TbFactura entity)
        {
            try
            {
                _context.TbFacturas.Add(entity);
                await _context.SaveChangesAsync();
                return entity;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<TbFactura> obtenerPorId(TbFactura entity)
        {
            try
            {
                return await _context.TbFacturas.Include("TbDetalleFacturas").Where(x => x.IdFactura == entity.IdFactura && x.Estado==true).AsNoTracking().SingleOrDefaultAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<TbFactura>> obtenerTodos()
        {
            try
            {
                return await _context.TbFacturas.Include("TbDetalleFacturas").Where(x=>x.Estado==true).AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
