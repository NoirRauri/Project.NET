﻿using Entities;

namespace InaApi2.Models
{
    public class TipoVentaDTO
    {
        public string? Id { get; set; }

        public string? Nombre { get; set; }

        public bool Estado { get; set; }

    }
}
