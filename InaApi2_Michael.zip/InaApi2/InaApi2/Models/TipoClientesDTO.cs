﻿using Entities;

namespace InaApi2.Models
{
    public class TipoClientesDTO
    {
        public int Id { get; set; }

        public string? Nombre { get; set; }

        public bool Estado { get; set; }

    }
}
