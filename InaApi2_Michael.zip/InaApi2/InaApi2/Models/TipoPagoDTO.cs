﻿using Entities;

namespace InaApi2.Models
{
    public class TipoPagoDTO
    {
        public string? Id { get; set; }

        public string? Nombre { get; set; }

        public bool Estado { get; set; }

    }
}
